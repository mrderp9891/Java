package projectoop;

import java.io.Serializable;

public enum Degree implements Serializable
{
    TUTOR, LECTOR, SENIOR_LECTOR, PROFESSOR;
}